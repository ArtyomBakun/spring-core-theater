package ua.epam.spring.hometask.domain;

/**
 * Created by artyom on 04.06.17.
 */
public class Booking {

}
